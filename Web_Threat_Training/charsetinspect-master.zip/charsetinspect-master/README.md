# charsetinspect
A script that inspects multi-byte character sets looking for characters with specific user-defined properties

Usage:
python3 charset_inspect.py -n [needle] [-e] [-s] [-c]

Example:
python3 charset_inspect.py -n \\ -e

More details available at http://howto.hackallthethings.com/2016/06/using-multi-byte-characters-to-nullify.html
